package mk.ukim.finki.wpproekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WpProektApplicationTests {

    @Test
    void contextLoads() {
    }

}
