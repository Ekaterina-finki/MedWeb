package mk.ukim.finki.wpproekt.model;

import lombok.Data;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Entity
public class Korisnik implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long covek_id;
    private String username;
    private String password;
    @Column(columnDefinition = "bpchar(13)")
    private String embg;
    private String ime;
    private String prezime;
    @Enumerated(value = EnumType.STRING)
    private Role role;

    private boolean isAccountNonExpired = true;
    private boolean isAccountNonLocked = true;
    private boolean isCredentialsNonExpired = true;
    private boolean isEnabled = true;

    @ManyToOne
    private Specijalnost specijalnost;

    @ManyToOne
    private Oddel oddel;

    @OneToMany(mappedBy = "korisnik", fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @Fetch(value = FetchMode.SUBSELECT)
    private List<Termin> terminList;

    @OneToMany(mappedBy = "korisnik")
    private List<PrepisaniLekovi> prepisaniLekovi;

    @OneToMany(mappedBy = "korisnik")
    private List<Upat> upatList;

    public Korisnik() {
    }

    public Korisnik(String username, String password, String embg, String ime, String prezime, Role role,
                    Specijalnost specijalnost, Oddel oddel) {
        this.username = username;
        this.password = password;
        this.embg = embg;
        this.ime = ime;
        this.prezime = prezime;
        this.role = role;
        this.specijalnost = specijalnost;
        this.oddel = oddel;
    }

    public Long getCovek_id() {
        return covek_id;
    }

    public void setCovek_id(Long covek_id) {
        this.covek_id = covek_id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Specijalnost getSpecijalnost() {
        return specijalnost;
    }

    public void setSpecijalnost(Specijalnost specijalnost) {
        this.specijalnost = specijalnost;
    }

    public Oddel getOddel() {
        return oddel;
    }

    public void setOddel(Oddel oddel) {
        this.oddel = oddel;
    }

    public List<Termin> getTerminList() {
        return terminList;
    }

    public void setTerminList(List<Termin> terminList) {
        this.terminList = terminList;
    }

    public List<PrepisaniLekovi> getPrepisaniLekovi() {
        return prepisaniLekovi;
    }

    public void setPrepisaniLekovi(List<PrepisaniLekovi> prepisaniLekovi) {
        this.prepisaniLekovi = prepisaniLekovi;
    }

    public List<Upat> getUpatList() {
        return upatList;
    }

    public void setUpatList(List<Upat> upatList) {
        this.upatList = upatList;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList(role);
    }

    @Override
    public boolean isAccountNonExpired() {
        return isAccountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return isAccountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return isCredentialsNonExpired;
    }

    @Override
    public boolean isEnabled() {
        return isEnabled;
    }

}
