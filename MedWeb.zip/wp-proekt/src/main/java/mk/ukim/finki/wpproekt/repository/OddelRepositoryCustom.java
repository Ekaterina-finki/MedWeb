package mk.ukim.finki.wpproekt.repository;

import mk.ukim.finki.wpproekt.model.Korisnik;
import mk.ukim.finki.wpproekt.model.Oddel;
import mk.ukim.finki.wpproekt.model.Upat;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface OddelRepositoryCustom {

  Optional <Oddel> findByOddelId (Long oddel_id);



}
