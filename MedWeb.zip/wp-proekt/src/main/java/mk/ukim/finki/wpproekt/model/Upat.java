package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.*;


@Entity
public class Upat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long upat_id;
    private String dijagnoza;

    @ManyToOne
    @JoinColumn(name = "covek_id", referencedColumnName = "covek_id", nullable = false)
    private Korisnik korisnik;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "bolnica_id", referencedColumnName = "bolnica_id", nullable = false),
            @JoinColumn(name = "oddel_id", referencedColumnName = "oddel_id", nullable = false)
    })
    private Oddel oddel;

    private String doktor;

    @OneToOne(mappedBy = "upat")
    private Rezervacija rezervacija;

    public Upat() {
    }

    public Upat(String dijagnoza) {

        this.dijagnoza = dijagnoza;
    }

    public Upat(Long id) {
    }

    public Upat(String dijagnoza, Korisnik korisnik, Oddel oddel, String doktor) {
        this.dijagnoza = dijagnoza;
        this.korisnik = korisnik;
        this.oddel = oddel;
        this.doktor = doktor;
    }

    public Long getUpat_id() {
        return upat_id;
    }

    public void setUpat_id(Long upat_id) {
        this.upat_id = upat_id;
    }

    public String getDijagnoza() {
        return dijagnoza;
    }

    public void setDijagnoza(String dijagnoza) {
        this.dijagnoza = dijagnoza;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Oddel getOddel() {
        return oddel;
    }

    public void setOddel(Oddel oddel) {
        this.oddel = oddel;
    }

    public String getDoktor() {
        return doktor;
    }

    public void setDoktor(String doktor) {
        this.doktor = doktor;
    }

    public Rezervacija getRezervacija() {
        return rezervacija;
    }

    public void setRezervacija(Rezervacija rezervacija) {
        this.rezervacija = rezervacija;
    }
}
