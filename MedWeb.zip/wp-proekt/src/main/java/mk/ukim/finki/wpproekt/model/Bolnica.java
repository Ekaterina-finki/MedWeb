package mk.ukim.finki.wpproekt.model;


import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Bolnica {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bolnica_id;
    private String naziv;
    private String grad;
    private Integer broj;
    private String ulica;
    private String smetka_bolnica;

    public Bolnica() {
    }

    public Bolnica(String naziv, String grad, Integer broj, String ulica, String smetka_bolnica) {
        this.naziv = naziv;
        this.grad = grad;
        this.broj = broj;
        this.ulica = ulica;
        this.smetka_bolnica = smetka_bolnica;
    }

    public Long getBolnica_id() {
        return bolnica_id;
    }

    public void setBolnica_id(Long bolnica_id) {
        this.bolnica_id = bolnica_id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public Integer getBroj() {
        return broj;
    }

    public void setBroj(Integer broj) {
        this.broj = broj;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public String getSmetka_bolnica() {
        return smetka_bolnica;
    }

    public void setSmetka_bolnica(String smetka_bolnica) {
        this.smetka_bolnica = smetka_bolnica;
    }
}
