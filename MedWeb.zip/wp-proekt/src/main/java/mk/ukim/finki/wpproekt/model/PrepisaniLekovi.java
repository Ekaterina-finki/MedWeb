package mk.ukim.finki.wpproekt.model;


import lombok.Data;

import javax.persistence.*;

@Entity
@IdClass(PrepisaniLekoviId.class)
@Table(name = "prepishani_lekovi")
public class PrepisaniLekovi {

    @Id
    private Long covek_id;
    @Id
    private Long lek_id;
    @Id
    private String pacient_username;

    @Id
    @ManyToOne
    @JoinColumn(name = "covek_id", referencedColumnName = "covek_id", insertable = false, updatable = false)
    private Korisnik korisnik;

    @Id
    @ManyToOne
    @JoinColumn(name = "lek_id", referencedColumnName = "lek_id", insertable = false, updatable = false)
    private Lekovi lekovi;

    public PrepisaniLekovi() {

    }

    public PrepisaniLekovi(Korisnik korisnik, Lekovi lekovi, String pacient_username) {
        this.korisnik = korisnik;
        this.lekovi = lekovi;
        this.pacient_username = pacient_username;
    }

    public Long getCovek_id() {
        return covek_id;
    }

    public void setCovek_id(Long covek_id) {
        this.covek_id = covek_id;
    }

    public Long getLek_id() {
        return lek_id;
    }

    public void setLek_id(Long lek_id) {
        this.lek_id = lek_id;
    }

    public String getPacient_username() {
        return pacient_username;
    }

    public void setPacient_username(String pacient_username) {
        this.pacient_username = pacient_username;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Lekovi getLekovi() {
        return lekovi;
    }

    public void setLekovi(Lekovi lekovi) {
        this.lekovi = lekovi;
    }
}
