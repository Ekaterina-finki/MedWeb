package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
public class Lekovi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lek_id;
    private String ime_lek;
    private String genericko_ime;

    @OneToMany(mappedBy = "lekovi")
    private List<PrepisaniLekovi> prepisaniLekovi;

    public Lekovi() {
    }

    public Lekovi(String ime_lek, String genericko_ime) {
        this.ime_lek = ime_lek;
        this.genericko_ime = genericko_ime;
    }

    public Long getLek_id() {
        return lek_id;
    }

    public void setLek_id(Long lek_id) {
        this.lek_id = lek_id;
    }

    public String getIme_lek() {
        return ime_lek;
    }

    public void setIme_lek(String ime_lek) {
        this.ime_lek = ime_lek;
    }

    public String getGenericko_ime() {
        return genericko_ime;
    }

    public void setGenericko_ime(String genericko_ime) {
        this.genericko_ime = genericko_ime;
    }

    public List<PrepisaniLekovi> getPrepisaniLekovi() {
        return prepisaniLekovi;
    }

    public void setPrepisaniLekovi(List<PrepisaniLekovi> prepisaniLekovi) {
        this.prepisaniLekovi = prepisaniLekovi;
    }
}
