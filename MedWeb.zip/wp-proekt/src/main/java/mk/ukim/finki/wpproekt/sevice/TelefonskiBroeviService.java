package mk.ukim.finki.wpproekt.sevice;

import mk.ukim.finki.wpproekt.model.TelefonskiBroevi;

public interface TelefonskiBroeviService {

    public void save (TelefonskiBroevi telefonskiBroevi);
}
