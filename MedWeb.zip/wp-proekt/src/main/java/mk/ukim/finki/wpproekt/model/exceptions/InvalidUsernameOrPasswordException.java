package mk.ukim.finki.wpproekt.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException {
}
