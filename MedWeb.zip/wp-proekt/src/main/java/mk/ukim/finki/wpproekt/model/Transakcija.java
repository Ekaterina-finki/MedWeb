package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.*;

@Entity
public class Transakcija {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tran_id;
    private Integer suma;
    private String smetka_bolnica;

    @OneToOne
    @JoinColumn(name = "rezervacija_id", referencedColumnName = "rezervacija_id", nullable = true)
    private Rezervacija rezervacija;

    public Transakcija() {
    }

    public Transakcija(Integer suma, String smetka_bolnica, Rezervacija rezervacija) {
        this.suma = suma;
        this.smetka_bolnica = smetka_bolnica;
        this.rezervacija = rezervacija;
    }

    public Long getTran_id() {
        return tran_id;
    }

    public void setTran_id(Long tran_id) {
        this.tran_id = tran_id;
    }

    public Integer getSuma() {
        return suma;
    }

    public void setSuma(Integer suma) {
        this.suma = suma;
    }

    public String getSmetka_bolnica() {
        return smetka_bolnica;
    }

    public void setSmetka_bolnica(String smetka_bolnica) {
        this.smetka_bolnica = smetka_bolnica;
    }

    public Rezervacija getRezervacija() {
        return rezervacija;
    }

    public void setRezervacija(Rezervacija rezervacija) {
        this.rezervacija = rezervacija;
    }
}
