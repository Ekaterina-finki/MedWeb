package mk.ukim.finki.wpproekt.repository;

import mk.ukim.finki.wpproekt.model.Korisnik;
import mk.ukim.finki.wpproekt.model.Lekovi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LekoviRepository extends JpaRepository<Lekovi, Long> {
}
