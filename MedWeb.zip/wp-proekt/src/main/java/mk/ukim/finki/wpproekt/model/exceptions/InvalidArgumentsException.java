package mk.ukim.finki.wpproekt.model.exceptions;

public class InvalidArgumentsException extends RuntimeException {
    public InvalidArgumentsException() {

        super("Invalid arguments exception");
    }
}
