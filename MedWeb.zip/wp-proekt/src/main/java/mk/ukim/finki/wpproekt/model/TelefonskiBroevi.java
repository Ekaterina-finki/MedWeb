package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(TelefonskiBroeviId.class)
public class TelefonskiBroevi {
    @Id
    private Long covek_broj_id;

    @Id
    private String telefonski_broj;

    public TelefonskiBroevi() {
    }

    public Long getCovek_broj_id() {
        return covek_broj_id;
    }

    public void setCovek_broj_id(Long covek_broj_id) {
        this.covek_broj_id = covek_broj_id;
    }

    public String getTelefonski_broj() {
        return telefonski_broj;
    }

    public void setTelefonski_broj(String telefonski_broj) {
        this.telefonski_broj = telefonski_broj;
    }
}
