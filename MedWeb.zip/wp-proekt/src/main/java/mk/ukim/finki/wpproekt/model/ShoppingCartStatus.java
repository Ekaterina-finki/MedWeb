package mk.ukim.finki.wpproekt.model;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}
