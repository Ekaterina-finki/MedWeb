package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Specijalnost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long spec_id;
    private String naziv;

    public Specijalnost() {
    }

    public Specijalnost(String naziv) {

        this.naziv = naziv;
    }

    public Long getSpec_id() {
        return spec_id;
    }

    public void setSpec_id(Long spec_id) {
        this.spec_id = spec_id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
}
