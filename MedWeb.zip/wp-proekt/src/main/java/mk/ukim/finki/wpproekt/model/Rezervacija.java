package mk.ukim.finki.wpproekt.model;

import lombok.Data;

import javax.persistence.*;

@Entity
public class Rezervacija {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rezervacija_id;

    @OneToOne
    @JoinColumn(name = "upat_id", referencedColumnName = "upat_id")
    private Upat upat;

    @OneToOne
    @JoinColumns({
            @JoinColumn(name = "covek_id", referencedColumnName = "covek_id"),
            @JoinColumn(name = "termin_id", referencedColumnName = "termin_id")
    })
    private Termin termin;

    @OneToOne(mappedBy = "rezervacija")
    private Transakcija transakcija;

    public Rezervacija() {
    }

    public Rezervacija(Upat upat, Termin termin) {
        this.upat = upat;
        this.termin = termin;
    }

    public Long getRezervacija_id() {
        return rezervacija_id;
    }

    public void setRezervacija_id(Long rezervacija_id) {
        this.rezervacija_id = rezervacija_id;
    }

    public Upat getUpat() {
        return upat;
    }

    public void setUpat(Upat upat) {
        this.upat = upat;
    }

    public Termin getTermin() {
        return termin;
    }

    public void setTermin(Termin termin) {
        this.termin = termin;
    }

    public Transakcija getTransakcija() {
        return transakcija;
    }

    public void setTransakcija(Transakcija transakcija) {
        this.transakcija = transakcija;
    }
}
