package mk.ukim.finki.wpproekt.sevice.impl;

import mk.ukim.finki.wpproekt.model.*;
import mk.ukim.finki.wpproekt.model.exceptions.InvalidArgumentsException;
import mk.ukim.finki.wpproekt.model.exceptions.KorisnikNotFoundException;
import mk.ukim.finki.wpproekt.model.exceptions.OddelNotFoundException;
import mk.ukim.finki.wpproekt.model.exceptions.UpatNotFoundException;
import mk.ukim.finki.wpproekt.repository.*;
import mk.ukim.finki.wpproekt.sevice.UpatService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;
import java.util.Optional;
@Service
public class UpatServiceImpl implements UpatService{

    private final UpatRepository upatRepository;
    private final OddelRepository oddelRepository;
    private final KorisnikRepository korisnikRepository;
    private final RezervacijaRepository rezervacijaRepository;

    public UpatServiceImpl(UpatRepository upatRepository, OddelRepository oddelRepository, KorisnikRepository korisnikRepository, RezervacijaRepository rezervacijaRepository) {
        this.upatRepository = upatRepository;
        this.oddelRepository = oddelRepository;
        this.korisnikRepository = korisnikRepository;
        this.rezervacijaRepository = rezervacijaRepository;
    }

    @Override
    public Optional<Upat> findById(Long id) {
        return this.upatRepository.findById(id);
    }

    @Override
    public List<Upat> findAll() {
        return this.upatRepository.findAll();
    }

    @Override
    public List<Upat> findAllWithoutReservation() {
        return this.upatRepository.findAllWithoutReservation();
    }

    @Override
    public Optional<Upat> selectedUpat(Long upat_id) {
        if (upat_id == null) {
            throw new InvalidArgumentsException();
        }
        return this.upatRepository.findById(upat_id);
    }

    @Override
    @Transactional
    public Optional<Upat> edit(Long upat_id, String dijagnoza, Long korisnikId, Long oddelId,  String doktor) {
        Upat upat = this.upatRepository.findById(upat_id).orElseThrow(()
                -> new UpatNotFoundException(upat_id));

        upat.setDijagnoza(dijagnoza);

        Oddel oddel = this.oddelRepository.findByOddelId(oddelId)
                .orElseThrow(() -> new OddelNotFoundException(oddelId));
        upat.setOddel(oddel);

        Korisnik korisnik = this.korisnikRepository.findById(korisnikId)
                .orElseThrow(() -> new KorisnikNotFoundException(korisnikId));
        upat.setKorisnik(korisnik);

        upat.setDoktor(doktor);

        return Optional.of(this.upatRepository.save(upat));
    }

    @Override
    public Optional<Upat> save(String dijagnoza, Long korisnikId, Long oddelId, String doktor) {
        Oddel oddel = this.oddelRepository.findByOddelId(oddelId)
                .orElseThrow(() -> new OddelNotFoundException(oddelId));
        Korisnik korisnik = this.korisnikRepository.findById(korisnikId)
                .orElseThrow(() -> new KorisnikNotFoundException(korisnikId));
        return Optional.of(this.upatRepository.save(new Upat(dijagnoza, korisnik, oddel, doktor)));
    }

    @Override
    public void deleteById(Long upat_id) {

        List<Rezervacija> rezervacijaList = this.rezervacijaRepository.findAll();
        for (Rezervacija rezervacija : rezervacijaList) {
            if (rezervacija.getUpat().getUpat_id().equals(upat_id)) {
                this.rezervacijaRepository.delete(rezervacija);
            }
        }
        this.upatRepository.deleteById(upat_id);
    }

}
